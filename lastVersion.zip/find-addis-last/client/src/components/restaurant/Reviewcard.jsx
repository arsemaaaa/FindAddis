import React from "react";
import StarRating from "../common/StarRating";
import Modal from "../common/Modal";
import { useState, useContext } from "react";
import RestaurantsContext from "../../context/RestaurantsContext";
import AuthContext from "../../context/AuthContext";

function ReviewCard({ review, username, restaurantId }) {
  const { editReview, deleteReview } = useContext(RestaurantsContext);
  const { user, isAdmin } = useContext(AuthContext);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ rating: review.rating, text: review.text });

  function canEdit() {
    if (!user) return false;
    return isAdmin() || user.name === review.user || user.email === review.user;
  }

  function handleSave() {
    editReview(restaurantId, review.id, { rating: form.rating, text: form.text });
    setOpen(false);
  }

  const [showDeleteModal, setShowDeleteModal] = useState(false);

  function confirmDelete() {
    deleteReview(restaurantId, review.id);
    setShowDeleteModal(false);
  }

  return (
    <div className="review-card">
      <div className="review-header">
        <div className="review-user">{review.user}</div>
        <StarRating value={review.rating} />
      </div>
      <div className="review-text"><b>{username}</b></div>
      <div className="review-text">{review.text}</div>
      <div className="review-date">{review.date}</div>
      {canEdit() && (
        <div className="review-actions">
          <button className="button" onClick={() => setOpen(true)}>Edit</button>
          <button className="button button-ghost" onClick={() => setShowDeleteModal(true)}>Delete</button>
        </div>
      )}

      <Modal title={`Edit review — ${review.user}`} open={open} onClose={() => setOpen(false)}>
        <div className="form-row">
          <label>Rating</label>
          <input type="number" min="1" max="5" value={form.rating} onChange={(e) => setForm((f) => ({ ...f, rating: Number(e.target.value) }))} />
        </div>
        <div className="form-row">
          <label>Text</label>
          <textarea value={form.text} onChange={(e) => setForm((f) => ({ ...f, text: e.target.value }))} />
        </div>
        <div className="modal-actions">
          <button className="button button-primary" onClick={handleSave}>Save</button>
          <button className="button button-ghost" onClick={() => setOpen(false)}>Cancel</button>
        </div>
      </Modal>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="modal-overlay" onClick={() => setShowDeleteModal(false)}>
          <div className="modal-content" onClick={e => e.stopPropagation()}>
            <h3 className="modal-title">Delete Review</h3>
            <div className="modal-body">
              Are you sure you want to delete this review?
            </div>
            <div className="modal-actions">
              <button className="modal-btn modal-btn-cancel" onClick={() => setShowDeleteModal(false)}>Cancel</button>
              <button className="modal-btn modal-btn-danger" onClick={confirmDelete}>Delete</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default ReviewCard;
