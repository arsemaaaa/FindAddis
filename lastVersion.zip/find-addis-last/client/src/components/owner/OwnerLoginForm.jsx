import React from "react";
import LoginForm from "../components/user/LoginForm";
import { useContext } from "react";
import AuthContext from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

import { useToast } from "../context/ToastContext";

function OwnerLogin() {
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();
  const addToast = useToast();

  async function handleLogin(credentials) {
    try {
      await login(credentials);
      navigate("/");
    } catch (e) {
      addToast(e, 'error');
    }
  }

  return (
    <div className="login-page container">
      <h1 className="page-title">Log in</h1>
      <LoginForm onLogin={handleLogin} />
    </div>
  );
}

export default OwnerLogin;
