import React from "react";
import { useState, useContext } from "react";
import InputField from "../common/InputField";
import Button from "../common/Button";
import AuthContext from "../../context/AuthContext";
import axios from "axios";
import RestaurantsContext from "../../context/RestaurantsContext";
import { useToast } from "../../context/ToastContext";

function OwnerRestaurantRegistrationForm({ onSuccess, initialData, isEditing = false }) {
    const [form, setForm] = useState(initialData || { name: "", category: "", address: "", hours: "", description: "", menu: "", latitude: "", longitude: "" });
    const [imageDataUrl, setImageDataUrl] = useState((initialData && initialData.images && initialData.images[0]) || ""); // full data URL with prefix
    const [imagePreview, setImagePreview] = useState((initialData && initialData.images && initialData.images[0]) || null);
    const { token } = useContext(AuthContext);
    const addToast = useToast();

    // Effect to update form if initialData changes (e.g. when opening modal repeatedly)
    React.useEffect(() => {
        if (initialData) {
            setForm({
                name: initialData.name || "",
                category: initialData.category || "",
                address: initialData.address || "",
                hours: initialData.hours || "",
                description: initialData.description || "",
                menu: initialData.menu ? (Array.isArray(initialData.menu) ? initialData.menu.join(", ") : initialData.menu) : "",
                latitude: initialData.location?.lat || "",
                longitude: initialData.location?.lng || ""
            });
            const img = initialData.images && initialData.images[0];
            setImageDataUrl(img || "");
            setImagePreview(img || null);
        }
    }, [initialData]);


    function handleChange(e) {
        setForm({ ...form, [e.target.name]: e.target.value });
    }

    const handleImageChange = (e) => {
        const file = e.target.files && e.target.files[0];
        if (!file) return;

        const validTypes = ["image/jpeg", "image/png", "image/gif", "image/webp"];
        if (!validTypes.includes(file.type)) {
            addToast("Please select a valid image (jpg, png, gif, webp).", 'error');
            return;
        }

        const maxSize = 3 * 1024 * 1024; // 3MB
        if (file.size > maxSize) {
            addToast("Image is too large. Max size is 3MB.", 'error');
            return;
        }

        const reader = new FileReader();
        reader.onloadend = () => {
            // reader.result is a data URL: data:<type>;base64,<data>
            const dataUrl = reader.result;
            // store the full data URL (including the data:image/...;base64, prefix)
            setImageDataUrl(dataUrl);
            setImagePreview(dataUrl);
        };
        reader.readAsDataURL(file);
    };


    async function handleSubmit(e) {
        e.preventDefault();
        try {
            const payload = {
                name: form.name,
                category: form.category,
                address: form.address,
                hours: form.hours,
                description: form.description,
                menu: form.menu ? form.menu.split(",").map(item => item.trim()) : [],
                location: {
                    lat: form.latitude,
                    lng: form.longitude
                },
                images: imageDataUrl ? [imageDataUrl] : [] // send as an array with full data URL prefix
            };

            let res;
            if (isEditing && initialData) {
                // EDIT MODE
                res = await axios.patch(`http://localhost:3000/api/restaurants/${initialData._id}`,
                    payload,
                    {
                        headers: {
                            Authorization: `Bearer ${token}`,
                        }
                    });
            } else {
                // CREATE MODE
                res = await axios.post("http://localhost:3000/api/restaurants",
                    payload,
                    {
                        headers: {
                            Authorization: `Bearer ${token}`,
                        }
                    });
            }


            if (res.status >= 200 && res.status < 300) {
                // If the response contains a specific message, rely on it, otherwise default.
                const successMsg = isEditing ? "Restaurant updated successfully!" : (res.data?.message || "Restaurant submitted for approval!");
                addToast(successMsg, 'success');

                if (!isEditing) {
                    // reset form only if creating
                    setForm({ name: "", category: "", address: "", hours: "", description: "", menu: "", price: "", latitude: "", longitude: "" });
                    setImageDataUrl("");
                    setImagePreview(null);
                }

                if (onSuccess) onSuccess(res.data);

            } else {
                addToast(res.data?.message || "Error submitting restaurant", 'error');
            }
        } catch (err) {
            console.error(err);
            addToast(err.response?.data?.message || "Server error", 'error');
        }
    }

    return (
        <form className="signup-form" onSubmit={handleSubmit}>
            <InputField name="name" label="Name" value={form.name} onChange={handleChange} placeholder="Restaurant name" />
            <InputField name="category" label="Category" value={form.category} onChange={handleChange} placeholder="Ethiopian,Italian..." />
            <InputField name="address" label="Address" value={form.address} onChange={handleChange} placeholder="Bole, Addis Ababa" />
            <InputField name="hours" label="Hours" type="text" value={form.hours} onChange={handleChange} placeholder="Enter Working hours" />
            <InputField name="description" label="Description" value={form.description} onChange={handleChange} placeholder="Enter what you serve" />
            <InputField name="menu" label="Menu" type="text" value={form.menu} onChange={handleChange} placeholder="e.g. injera, tibs, coffee" />
            <InputField name="latitude" label="Latitude" type="number" value={form.latitude} onChange={handleChange} placeholder="Lat" />
            <InputField name="longitude" label="Longitude" type="number" value={form.longitude} onChange={handleChange} placeholder="Long" />
            <div className="form-group" style={{ marginBottom: 12 }}>
                <label htmlFor="image">Profile Image</label>
                <input id="image" name="image" type="file" accept="image/*" onChange={handleImageChange} />
                {imagePreview && (
                    <div style={{ marginTop: 8 }}>
                        <img src={imagePreview} alt="Preview" style={{ width: 150, height: 'auto', display: 'block', borderRadius: 6 }} />
                        <button type="button" style={{ marginTop: 6 }} onClick={() => { setImagePreview(null); setImageDataUrl(""); }}>Remove</button>
                    </div>
                )}
            </div>

            <Button type="submit">{isEditing ? "Update Restaurant" : "Add Restaurant"}</Button>
        </form>
    );
}

export default OwnerRestaurantRegistrationForm;
