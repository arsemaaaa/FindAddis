import React from "react";
import OwnerSignupForm from "../components/owner/OwnerSignupForm";
import { useContext } from "react";
import AuthContext from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

import { useToast } from "../context/ToastContext";

function OwnerSignUp() {
  const { signup } = useContext(AuthContext);
  const navigate = useNavigate();
  const addToast = useToast();

  async function handleSignup(details) {
    try {
      await signup(details);
      navigate("/");
    } catch (e) {
      addToast(e, 'error');
    }
  }

  return (
    <div className="signup-page container">
      <h1 className="page-title">Create an account</h1>
      <OwnerSignupForm onSignup={handleSignup} />
    </div>
  );
}

export default OwnerSignUp;
