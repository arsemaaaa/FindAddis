import Modal from "../components/common/Modal";
import React, { useContext, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import AuthContext from "../context/AuthContext";
import RestaurantsContext from "../context/RestaurantsContext";
import FeaturedCard from "../components/home/FeaturedCard";
import OwnerRestaurantRegistrationForm from "../components/owner/OwnerAddRestaurantForm";
import axios from "axios";

function OwnerDashboard() {
    const { user, token } = useContext(AuthContext);
    const { setRestaurants } = useContext(RestaurantsContext); // update global context
    const [ownerRestaurants, setOwnerRestaurants] = useState([]); // local state for this dashboard
    const [showForm, setShowForm] = useState(false);
    const [editingRestaurant, setEditingRestaurant] = useState(null);
    const navigate = useNavigate();

    // Fetch owned restaurants on mount
    useEffect(() => {
        const fetchOwnedRestaurants = async () => {
            try {
                const res = await axios.get("http://localhost:3000/api/owners/restaurants", {
                    headers: { Authorization: `Bearer ${token}` },
                });
                setOwnerRestaurants(res.data); // res.data is an array of restaurant objec
            } catch (err) {
                console.error("Failed to fetch owned restaurants:", err);
            }
        };
        if (token) fetchOwnedRestaurants();
    }, [token])

    return (
        <main className="dashboard-page container">
            <h1>Welcome, {user.name}</h1>

            <section className="dashboard-actions">
                <button
                    className="button button-primary"
                    onClick={() => setShowForm(!showForm)} // show form on click
                >
                    + Add New Restaurant
                </button>
            </section>

            {/* Show form when toggled */}
            <Modal
                title={editingRestaurant ? "Edit Restaurant" : "Add New Restaurant"}
                open={showForm || !!editingRestaurant}
                onClose={() => {
                    setShowForm(false);
                    setEditingRestaurant(null);
                }}
            >
                <OwnerRestaurantRegistrationForm
                    ownerId={user._id}
                    isEditing={!!editingRestaurant}
                    initialData={editingRestaurant}
                    onSuccess={(data) => {
                        if (editingRestaurant) {
                            // Update local state
                            setOwnerRestaurants(prev => prev.map(r => r._id === data._id ? data : r));
                            // Update global state
                            setRestaurants(prev => prev.map(r => r._id === data._id ? data : r));
                        } else {
                            // Add new
                            setOwnerRestaurants([...ownerRestaurants, data.request || data]);
                            // Note: Request response structure might differ, ensure we handle it. 
                            // If it's a request, usually we don't add to main restaurants list until approved.
                            // But for owner dashboard, we might want to see it? 
                            // Assuming currently it adds directly or via request. 
                        }
                        setShowForm(false);
                        setEditingRestaurant(null);
                    }}
                />
            </Modal>

            <section className="owner-restaurants">
                <h2>Your Restaurants</h2>
                {ownerRestaurants.length === 0 ? (
                    <p>No restaurants yet</p>
                ) : (
                    <div className="featured-row">
                        {ownerRestaurants.map((r) => (
                            <FeaturedCard
                                key={r._id}
                                restaurant={r}
                                showDeleteButton={true}
                                onEdit={() => setEditingRestaurant(r)}
                            />
                        ))}
                    </div>
                )}
            </section>
        </main>
    );
}

export default OwnerDashboard;
