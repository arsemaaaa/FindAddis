import React, { useContext, useState } from "react";
import LoginForm from "../components/user/LoginForm";
import AuthContext from "../context/AuthContext";
import { useNavigate } from "react-router-dom";

function AdminLogin() {
    const { adminLogin } = useContext(AuthContext);
    const navigate = useNavigate();
    const [error, setError] = useState(null);

    async function handleLogin(credentials) {
        setError(null);
        try {
            await adminLogin({
                email: credentials.email,
                password: credentials.password
            });
            navigate("/admin/dashboard");
        } catch (e) {
            setError(e);
        }
    }

    return (
        <div className="login-page container">
            <h1 className="page-title">Admin Login</h1>
            {error && (
                <div className="alert-error" style={{
                    color: '#721c24',
                    backgroundColor: '#f8d7da',
                    borderColor: '#f5c6cb',
                    padding: '.75rem 1.25rem',
                    marginBottom: '1rem',
                    borderRadius: '.25rem',
                    border: '1px solid transparent'
                }}>
                    {error}
                </div>
            )}
            <LoginForm onLogin={handleLogin} />
        </div>
    );
}

export default AdminLogin;
