import React, { useEffect, useState, useContext } from 'react';
import axios from 'axios';
import AuthContext from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import { useToast } from '../context/ToastContext';

function AdminDashboard() {
    const { token, logout, user } = useContext(AuthContext);
    const navigate = useNavigate();
    const addToast = useToast();
    const [requests, setRequests] = useState([]);
    const [loading, setLoading] = useState(true);
    const [stats, setStats] = useState(null);

    useEffect(() => {
        if (!token) {
            navigate('/admin/login');
            return;
        }
        // Check role from token or user object if available
        if (user && user.role !== 'admin') {
            // navigate('/'); 
            // User might be just logging in so 'user' triggers this effect. 
        }
        fetchData();
    }, [token, user]);

    async function fetchData() {
        try {
            const [reqsRes, statsRes] = await Promise.all([
                axios.get('http://localhost:3000/api/admin/requests/pending', {
                    headers: { Authorization: `Bearer ${token}` }
                }),
                axios.get('http://localhost:3000/api/admin/dashboard/stats', {
                    headers: { Authorization: `Bearer ${token}` }
                })
            ]);
            setRequests(reqsRes.data);
            setStats(statsRes.data);
        } catch (err) {
            console.error("Error fetching admin data", err);
            // If unauthorized, maybe token expired or not admin
            if (err.response && err.response.status === 403) {
                // Handle unauthorized
            }
        } finally {
            setLoading(false);
        }
    }

    const [modal, setModal] = useState({ show: false, type: '', id: null });
    const [rejectReason, setRejectReason] = useState("");

    // ... existing useEffect and fetchData ...

    function openApproveModal(id) {
        setModal({ show: true, type: 'approve', id });
    }

    function openRejectModal(id) {
        setModal({ show: true, type: 'reject', id });
        setRejectReason("");
    }

    function closeModal() {
        setModal({ show: false, type: '', id: null });
    }

    async function handleApprove() {
        try {
            await axios.post(`http://localhost:3000/api/admin/requests/${modal.id}/approve`, {}, {
                headers: { Authorization: `Bearer ${token}` }
            });
            addToast("Restaurant Approved!", 'success');
            fetchData();
        } catch (err) {
            console.error("Approve error:", err);
            const errMsg = err.response?.data?.error || err.message || "Failed to approve";
            addToast(`Error: ${errMsg}`, 'error');
        } finally {
            closeModal();
        }
    }

    async function handleReject() {
        if (!rejectReason.trim()) {
            addToast("Please provide a reason for rejection", 'error');
            return;
        }

        try {
            await axios.post(`http://localhost:3000/api/admin/requests/${modal.id}/reject`, { reason: rejectReason }, {
                headers: { Authorization: `Bearer ${token}` }
            });
            addToast("Restaurant Rejected", 'info');
            fetchData();
        } catch (err) {
            console.error("Reject error:", err);
            const errMsg = err.response?.data?.error || err.message || "Failed to reject";
            addToast(`Error: ${errMsg}`, 'error');
        } finally {
            closeModal();
        }
    }

    if (loading) return <div className="container">Loading Dashboard...</div>;

    return (
        <div className="container" style={{ padding: '2rem 1rem' }}>
            <header style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
                <h1>Admin Dashboard</h1>
                <button className="button" onClick={() => { logout(); navigate('/admin/login'); }}>Logout</button>
            </header>

            {/* Custom Modal */}
            {modal.show && (
                <div className="modal-overlay" onClick={closeModal}>
                    <div className="modal-content" onClick={e => e.stopPropagation()}>
                        <h3 className="modal-title">
                            {modal.type === 'approve' ? 'Approve Restaurant' : 'Reject Restaurant'}
                        </h3>

                        <div className="modal-body">
                            {modal.type === 'approve' ? (
                                <p>Are you sure you want to approve this restaurant? It will be immediately visible on the platform.</p>
                            ) : (
                                <div>
                                    <p style={{ marginBottom: '8px' }}>Please provide a reason for rejection:</p>
                                    <textarea
                                        value={rejectReason}
                                        onChange={(e) => setRejectReason(e.target.value)}
                                        style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ccc', minHeight: '80px' }}
                                        placeholder="e.g. Incomplete information, Low quality images..."
                                    />
                                </div>
                            )}
                        </div>

                        <div className="modal-actions">
                            <button className="modal-btn modal-btn-cancel" onClick={closeModal}>
                                Cancel
                            </button>
                            {modal.type === 'approve' ? (
                                <button className="modal-btn modal-btn-confirm" onClick={handleApprove}>
                                    Confirm Approval
                                </button>
                            ) : (
                                <button className="modal-btn modal-btn-danger" onClick={handleReject}>
                                    Reject Request
                                </button>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {stats && (
                <div style={{ display: 'flex', gap: '1rem', marginBottom: '2rem', flexWrap: 'wrap' }}>
                    <div className="stat-card" style={statStyle}>
                        <h3>Pending</h3>
                        <p style={{ fontSize: '2rem', fontWeight: 'bold' }}>{stats.pending}</p>
                    </div>
                    <div className="stat-card" style={statStyle}>
                        <h3>Approved</h3>
                        <p style={{ fontSize: '2rem', fontWeight: 'bold' }}>{stats.approved}</p>
                    </div>
                    <div className="stat-card" style={statStyle}>
                        <h3>Rejected</h3>
                        <p style={{ fontSize: '2rem', fontWeight: 'bold' }}>{stats.rejected}</p>
                    </div>
                    <div className="stat-card" style={statStyle}>
                        <h3>Total Live</h3>
                        <p style={{ fontSize: '2rem', fontWeight: 'bold' }}>{stats.totalRestaurants}</p>
                    </div>
                </div>
            )}

            <section>
                <h2>Pending Requests</h2>
                {requests.length === 0 ? (
                    <p>No pending requests.</p>
                ) : (
                    <div className="request-list" style={{ display: 'grid', gap: '1.5rem' }}>
                        {requests.map(req => (
                            <div key={req._id} className="request-card" style={cardStyle}>
                                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <div>
                                        <h3>{req.name}</h3>
                                        <p><strong>Category:</strong> {req.category}</p>
                                        <p><strong>Address:</strong> {req.address}</p>
                                        <p><strong>Owner:</strong> {req.ownerName} ({req.ownerEmail})</p>
                                        <p><strong>Date:</strong> {new Date(req.createdAt).toLocaleDateString()}</p>
                                    </div>
                                    {req.images && req.images.length > 0 && (
                                        <img src={req.images[0]} alt={req.name} style={{ width: '120px', height: '120px', objectFit: 'cover', borderRadius: '8px' }} />
                                    )}
                                </div>
                                <div style={{ marginTop: '1rem', display: 'flex', gap: '1rem' }}>
                                    <button className="button" style={{ backgroundColor: '#28a745', borderColor: '#28a745' }} onClick={() => openApproveModal(req._id)}>Approve</button>
                                    <button className="button" style={{ backgroundColor: '#dc3545', borderColor: '#dc3545' }} onClick={() => openRejectModal(req._id)}>Reject</button>
                                </div>
                            </div>
                        ))}
                    </div>
                )}
            </section>
        </div>
    );
}

const statStyle = {
    flex: '1 1 200px',
    padding: '1.5rem',
    backgroundColor: 'white',
    borderRadius: '8px',
    boxShadow: '0 2px 5px rgba(0,0,0,0.1)',
    textAlign: 'center'
};

const cardStyle = {
    padding: '1.5rem',
    backgroundColor: 'white',
    borderRadius: '8px',
    boxShadow: '0 2px 5px rgba(0,0,0,0.1)',
    borderLeft: '5px solid #ffc107' // yellow for pending
};

export default AdminDashboard;
