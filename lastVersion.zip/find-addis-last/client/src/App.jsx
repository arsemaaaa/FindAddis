import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Navbar from "./components/layout/Navbar";
import Footer from "./components/layout/Footer";

import Home from "./pages/Home";
import RestaurantListPage from "./pages/RestaurantListPage";
import RestaurantDetailsPage from "./pages/RestaurantDetailsPage";
import SearchResultsPage from "./pages/SearchResultsPage";
import WriteReviewPage from "./pages/WriteReviewPage";
import Login from "./pages/Login";
import OwnerLoginPage from "./pages/OwnerLoginPage"
import OwnerDashboard from "./pages/OwnerDashboard";
import AdminLogin from "./pages/AdminLogin";
import AdminDashboard from "./pages/AdminDashboard";
import Signup from "./pages/Signup";
import OwnerSignUp from "./pages/OwnerSignup";
import UserProfilePage from "./pages/UserProfilePage";
import Favorites from "./pages/Favorites";
import About from "./pages/About";
import Contact from "./pages/Contact";
import NotFound from "./pages/NotFound";

import { RestaurantsProvider } from "./context/RestaurantsContext";
import { AuthProvider } from "./context/AuthContext";
import { ToastProvider } from "./context/ToastContext";
import "./styles/main.css";







function App() {
  return (
    <BrowserRouter>
      <AuthProvider>
        <ToastProvider>
          <RestaurantsProvider>
            <div className="app-root">
              <Navbar />
              <main>
                <Routes>
                  <Route path="/" element={<Home />} />
                  <Route path="/restaurants" element={<RestaurantListPage />} />
                  <Route path="/restaurants/:id" element={<RestaurantDetailsPage />} />
                  <Route path="/search" element={<SearchResultsPage />} />
                  <Route path="/write-review" element={<WriteReviewPage />} />
                  <Route path="/login" element={<Login />} />
                  <Route path="/signup" element={<Signup />} />
                  <Route path="/OwnerSignUp" element={<OwnerSignUp />} />
                  <Route path="/OwnerDashboard" element={<OwnerDashboard />} />
                  <Route path="/OwnerLoginPage" element={<OwnerLoginPage />} />
                  <Route path="/admin/login" element={<AdminLogin />} />
                  <Route path="/admin/dashboard" element={<AdminDashboard />} />
                  <Route path="/profile" element={<UserProfilePage />} />
                  <Route path="/favorites" element={<Favorites />} />
                  <Route path="/contact" element={<Contact />} />
                  <Route path="/about" element={<About />} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </main>

              <Footer />
            </div>
          </RestaurantsProvider>
        </ToastProvider>
      </AuthProvider>
    </BrowserRouter>
  );
}

export default App;
