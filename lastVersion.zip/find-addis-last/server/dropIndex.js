import mongoose from 'mongoose';
import dotenv from 'dotenv';
import connectdb from './db/connection.js';

dotenv.config();

const dropIndex = async () => {
    try {
        await connectdb();

        console.log("Connected to DB...");

        const collections = await mongoose.connection.db.listCollections().toArray();
        const restaurantCollection = collections.find(c => c.name === 'restaurants');

        if (restaurantCollection) {
            console.log("Found restaurants collection. Checking indexes...");
            const indexes = await mongoose.connection.db.collection('restaurants').indexes();
            console.log("Current indexes:", indexes);

            const offendingIndex = indexes.find(idx => idx.name === 'id_1');
            if (offendingIndex) {
                console.log("Found offending index 'id_1'. Dropping it...");
                await mongoose.connection.db.collection('restaurants').dropIndex('id_1');
                console.log("Index 'id_1' dropped successfully.");
            } else {
                console.log("Index 'id_1' not found. It might have consistently been _id.");

                // Also check if there is any OTHER unique index that might be causing issues on 'id'
                const otherIdIndex = indexes.find(idx => idx.key && idx.key.id);
                if (otherIdIndex) {
                    console.log(`Found another index on 'id': ${otherIdIndex.name}. Dropping...`);
                    await mongoose.connection.db.collection('restaurants').dropIndex(otherIdIndex.name);
                    console.log("Dropped.");
                }
            }
        } else {
            console.log("Restaurants collection not found.");
        }

        process.exit(0);
    } catch (error) {
        console.error('Error dropping index:', error);
        process.exit(1);
    }
};

dropIndex();
