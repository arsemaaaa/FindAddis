import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import Admin from '../models/Admin.js';

// Load environment variables
dotenv.config();

// Connect to MongoDB
const connectDB = async () => {
    try {
        await mongoose.connect(process.env.MONGO_URI);
        console.log('✅ MongoDB connected successfully');
    } catch (err) {
        console.error('❌ MongoDB connection error:', err.message);
        process.exit(1);
    }
};

// Seed admin data
const seedAdmin = async () => {
    try {
        // Check if admin already exists
        const existingAdmin = await Admin.findOne({ email: 'admin@findaddis.com' });

        if (existingAdmin) {
            console.log('⚠️  Admin already exists. Skipping seed.');
            return;
        }

        // Hash the password
        const hashedPassword = await bcrypt.hash('Admin@123', 10);

        // Create admin
        const admin = new Admin({
            name: 'System Admin',
            email: 'admin@findaddis.com',
            password: hashedPassword,
            role: 'admin',
            isActive: true
        });

        await admin.save();
        console.log('✅ Admin created successfully!');
        console.log('📧 Email: admin@findaddis.com');
        console.log('🔑 Password: Admin@123');
        console.log('⚠️  IMPORTANT: Please change the password after first login!');

    } catch (err) {
        console.error('❌ Error seeding admin:', err.message);
    }
};

// Run the seed
const runSeed = async () => {
    await connectDB();
    await seedAdmin();
    await mongoose.connection.close();
    console.log('✅ Database connection closed');
    process.exit(0);
};

runSeed();
